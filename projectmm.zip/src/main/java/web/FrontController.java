package web;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.Command;
import common.MainDo;
import member.Login;
import notice.ListQuestion;
import store.ListStoreDo;
import store.ListTypeStore;
import store.SearchMapStoreDo;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	HashMap<String , Command> map;
	
	public FrontController() {
		map = new HashMap<>();
	}
	
	@Override
	public void init() throws ServletException {
		//홈페이지
		map.put("/main.do", new MainDo());
		
		//가게
		map.put("/listStore.do", new ListStoreDo());
		map.put("/searchMapStore.do", new SearchMapStoreDo());
		map.put("/listTypeStore.do", new ListTypeStore());
		
		//회원
		map.put("/login.do", new Login());
		
		//거의사항
		map.put("/listQuestion.do", new ListQuestion());
	}
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String uri = req.getRequestURI();//HelloWeb/hello.do
		String context = req.getContextPath();//HelloWeb
		String page = uri.substring(context.length());
		System.out.println(">"+page);
		
		
		Command command = map.get(page);
		String viewPage = command.exec(req, resp); //main/main.tiles
		//.do 요청 들어오면 리다이렉트 경로 안 써도된다?
		//삭제하는경우 바로 갱신되게 하는게 리다이렉트
		if(viewPage.endsWith(".do")) {
			resp.sendRedirect(viewPage);
		//forward는 삭제하고 새로고침해야 갱신 차이점을 아시겠나요?
		}else if(viewPage.endsWith(".tiles")) {
			RequestDispatcher rd = req.getRequestDispatcher(viewPage); 
			rd.forward(req, resp);
		}else if(viewPage.endsWith(".ajax")) {//{"id:"hong","age":20}.ajax
			resp.setContentType("text/json;charset=utf-8");
			resp.getWriter().print(viewPage.substring(0,viewPage.length()-5)); //.ajax 는 필요없어서 빼는것 json형태의{"id:"hong","age":20} 만 출력
			
		}
		
		
		
	}
}
