package reservation.dao;

public class ReservVO {

}
