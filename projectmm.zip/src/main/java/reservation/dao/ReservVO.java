package reservation.dao;

public class ReservVO {

	/*
	 * ORDER_NUM NUMBER(6,0)
	 * MEM_ID VARCHAR2(30 BYTE)
	 * STORE_ID NUMBER(6,0)
	 * PERSON_ID NUMBER(2,0)
	 * RESERVE_DATE DATE
	 * RESERVE_TIME DATE
	 */
	
	private String orderNum;
	private String MenId;
	private int StoreId;
	private int person;
	
	
}
