package store;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.Command;

public class ListStoreDo implements Command {

	@Override
	public String exec(HttpServletRequest req, HttpServletResponse resp) {
		return "store/listStore.tiles";
	}

}
